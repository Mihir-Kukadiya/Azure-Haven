import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private apiUrl = environment.apiUrl;

    constructor(private http: HttpClient) { }

    register(userData: any): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/register`, userData);
    }

    login(credentials: any): Observable<any> {
        return this.http.post<any>(`${this.apiUrl}/auth/login`, credentials);
    }

    logout(): void {
        localStorage.removeItem('user');
    }

    getUsers(): Observable<any> {
        return this.http.get<any>(`${this.apiUrl}/auth/users`);
    }

    getUserById(id: string): Observable<any> {
        return this.http.get<any>(`${this.apiUrl}/users/${id}`);
    }

    static getCurrentUser(): { id: string, username: string, role: string } | null {
        const userData = localStorage.getItem('user');
        if (userData) {
            try {
                const user = JSON.parse(userData);
                if (user && user.id && user.username && user.role) {
                    return user;
                }
            } catch (e) {
                // Invalid JSON
            }
        }
        return null;
    }
}
