import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoomService } from '../../../services/room.service';

@Component({
    selector: 'app-user-rooms',
    standalone: true,
    imports: [CommonModule],
    templateUrl: './rooms.component.html',
    styleUrl: './rooms.component.scss'
})
export class RoomsComponent implements OnInit {
    rooms: any[] = [];
    isLoading: boolean = false;
    @Output() bookRoom = new EventEmitter<any>();

    constructor(private roomService: RoomService) { }

    ngOnInit(): void {
        this.isLoading = true;
        this.roomService.getRooms().subscribe({
            next: (rooms: any) => {
                this.rooms = rooms.filter((room: any) => room.status === 'available');
                this.isLoading = false;
            },
            error: () => {
                this.isLoading = false;
            }
        });
    }
}
